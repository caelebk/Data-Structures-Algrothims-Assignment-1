#include "block.h"
#include <cmath>
#include <iostream>

int Block::width() const
{
/* your code here */
}

int Block::height() const
{
/* your code here */
}

void Block::render(PNG &im, int column, int row) const
{
/* your code here */
}

void Block::build(PNG &im, int column, int row, int width, int height)
{
/* your code here */
}

void Block::flip()
{
/* your code here */
}
